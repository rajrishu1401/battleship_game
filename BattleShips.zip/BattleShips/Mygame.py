import pygame
import time
import csv
import pandas as pd
import matplotlib.pyplot as plt
current_time = time.time()
class game:
    def __init__(self):
        pygame.init()
        self.screen=pygame.display.set_mode((1000,600))
        pygame.display.set_caption("THE SPACE BATTLE")
        self.bg_image=pygame.image.load("assets/images/space3.jpg").convert_alpha()
        self.bg_image2=pygame.image.load("assets/images/space3.jpg").convert_alpha()
        self.char_image=pygame.image.load("assets/images/jetsmall.png").convert_alpha()
        self.bullet_image=pygame.image.load("assets/images/anifre1.png").convert_alpha()
        self.fire_char_image=pygame.image.load("assets/images/firescrop.png").convert_alpha()
        self.enemy_image=pygame.image.load("assets/images/enemy.png").convert_alpha()
        self.lst_bullet=[]
        self.numlst=[1,-1]
        x=0
        for  i  in range(6):
            ld_image=self.bullet_image.subsurface(x,0,153.333,154)
            x+=153.33
            self.lst_bullet.append(ld_image)
        self.cooldfire_1=pygame.transform.scale(self.lst_bullet[0],(50,50))
        self.fire_enemy_image=pygame.image.load("assets/images/fire1done.png").convert_alpha()
        self.fire_enemy_image2=pygame.image.load("assets/images/upblast2.png").convert_alpha()
        self.lst_fire_char=[]
        self.lst_enemy_fire_image2=[]
        x=0
        y=0
        ld_image=self.fire_enemy_image2.subsurface(0,0,180,117)
        ld_image = pygame.transform.flip(ld_image, False, True)
        self.lst_enemy_fire_image2.append(ld_image)
        ld_image=self.fire_enemy_image2.subsurface(0,168,180,183)
        self.lst_enemy_fire_image2.append(ld_image)
        ld_image=self.fire_enemy_image2.subsurface(0,332,180,140)
        self.lst_enemy_fire_image2.append(ld_image)
        for j in range(3):
            x=0
            for  i  in range(4):
                ld_image=self.fire_char_image.subsurface(y,x,78.3,40.5)
                x+=40.5
                self.lst_fire_char.append(ld_image)
            y+=78.3
        self.cooldfire_2=pygame.transform.scale(self.lst_fire_char[1],(50,50))
        self.clock=pygame.time.Clock()
        self.pos=[False,False,False,False]
        self.position=[100,200]
        self.position_bullet1=[100,200]
        self.position_bullet2=[100,200]
        self.n=0
        self.a=0
        self.cooldown=0
        self.cooldown2=0
        self.cooldown_enemy=0
        self.position_enemy=[800,200]
        self.he=400
        self.font=pygame.font.Font("assets/font/turok.ttf", 80)
        self.con=True
        self.position_fire1=[100,200]
        self.position_fire2=[100,1000]
        self.position_fire2_1=[100,200]
        self.hc=200
        self.a1=1
        self.position_bg1=[0,0]
        self.position_bg2=[1000,0]
        self.c_anicool=0
        self.c_anicool2=0
        self.posf1=0
        self.kdidhit_2=0
        self.bullet_sound1=pygame.mixer.Sound("assets/audio/f1.mp3")
        self.bullet_sound1.set_volume(100)
        self.bullet_sound2=pygame.mixer.Sound("assets/audio/f2.mp3")
        self.bullet_sound2.set_volume(100)
        self.fire_sound1=pygame.mixer.Sound("assets/audio/fe1.mp3")
        self.fire_sound1.set_volume(100)
        self.fire_sound2=pygame.mixer.Sound("assets/audio/fe2.mp3")
        self.fire_sound2.set_volume(100)
        self.tim=1
        self.tim2=0
        self.tim21=0
        self.chtim=0
        self.chim=0
        self.chim1=0
        self.changebull=0
        self.changeb=0

    def movebg(self):
        self.position_bg1[0]-=1
        if(self.position_bg1[0]==-1000):
            self.position_bg1[0]=1000
        self.position_bg2[0]-=1
        if(self.position_bg2[0]==-1000):
            self.position_bg2[0]=1000
            
    def firecoold_animation(self):
        if(self.cooldown>0):
            self.c_anicool+=0.25
            modified_fire1=self.cooldfire_1.subsurface(0,0,self.c_anicool,50)
            self.screen.blit(modified_fire1,(20,540))
        if(self.cooldown==0):
            self.c_anicool=0
            self.screen.blit(self.cooldfire_1,(20,540))
        if(self.cooldown2>0):
            self.c_anicool2+=0.25
            modified_fire2=self.cooldfire_2.subsurface(0,0,self.c_anicool2,50)
            self.screen.blit(modified_fire2,(80,540))
        if(self.cooldown2==0):
            self.c_anicool2=0
            self.screen.blit(self.cooldfire_2,(80,540))

    def draw_bg(self):
        self.scaled_bg=pygame.transform.scale(self.bg_image,(1000,600))
        self.screen.blit(self.scaled_bg,self.position_bg1)
        self.scaled_bg2=pygame.transform.scale(self.bg_image2,(1000,600))
        self.screen.blit(self.scaled_bg2,self.position_bg2)

    def movement(self):
        if((((self.pos[1]-self.pos[0])*5)+self.position[1])>=0 and (((self.pos[1]-self.pos[0])*5)+self.position[1])<=500):
            self.position[1]+=(self.pos[1]-self.pos[0])*5
        if((((self.pos[3]-self.pos[2])*5)+self.position[0])>=0 and (((self.pos[3]-self.pos[2])*5)+self.position[0])<=930):
            self.position[0]+=(self.pos[3]-self.pos[2])*5

    def draw_bullet1(self,k,y):
        if(y[0]<1000):
            self.screen.blit(k[self.changebull],y)
            if self.changeb*1==1:    
                self.changebull+=1
                self.changeb=0
            self.changeb+=0.5
            if self.changebull==6:
                self.changebull=0
            y[0]+=5
            self.bullet_sound1.play()

    def draw_bullet2(self,k,y):
        if(y[0]<1000):
            self.screen.blit(k[1],y)
            y[0]+=5
            self.bullet_sound2.play()

    def draw_fire1(self,y):
        if(y[0]>0):
            self.screen.blit(self.fire_enemy_image,y)
            y[0]-=5
            self.fire_sound1.play()
        
    def draw_fire2(self,y):
        self.screen.blit(self.lst_enemy_fire_image2[1],y)
        y[1]+=5
        self.fire_sound2.play()
    def draw_fire2_1(self,y):
        self.screen.blit(self.lst_enemy_fire_image2[0],y)
        y[1]-=5

    def draw_fire2_2(self,y):
        self.screen.blit(self.lst_enemy_fire_image2[2],(y[0]-30,y[1]-40))
    
    def draw_char(self):
        self.screen.blit(self.char_image,self.position)

    def draw_enemy(self):
        self.screen.blit(self.enemy_image,self.position_enemy)

    def draw_char_rec(self):
        posi=[]
        posi.append(self.position[0]+75)
        posi.append(self.position[1])
        posi.append(10)
        posi.append(85)
        self.char_rect=pygame.draw.rect(self.screen,(255,255,255),posi)
        posi=[]
        posi.append(self.position[0]+5)
        posi.append(self.position[1])
        posi.append(80)
        posi.append(10)
        self.char_rect_up=pygame.draw.rect(self.screen,(255,0,255),posi)


    def draw_enemy_rec(self):
        posi=[]
        posi.append(self.position_enemy[0]+60)
        posi.append(self.position_enemy[1])
        posi.append(10)
        posi.append(236)
        self.enemy_rect=pygame.draw.rect(self.screen,(255,255,255),posi)

    def draw_bullet_rec(self,b):
        posi=[]
        posi.append(b[0]+170)
        posi.append(b[1]+20)
        posi.append(10)
        posi.append(60)
        self.bullet_rect=pygame.draw.rect(self.screen,(255,255,255),posi)

    def draw_fire_rec(self,b):
        posi=[]
        posi.append(b[0]+10)
        posi.append(b[1]+20)
        posi.append(10)
        posi.append(70)
        self.fire_rect=pygame.draw.rect(self.screen,(255,255,255),posi)
    
    def draw_fire2_rec(self,b):
        posi=[]
        posi.append(b[0]+50)
        posi.append(b[1]+120)
        posi.append(92)
        posi.append(10)
        self.fire2_rect=pygame.draw.rect(self.screen,(255,255,255),posi)
    
    def movement_enemy(self):
        if(self.cooldown_enemy<=5):
            self.position_enemy[1]=self.position[1]
        elif(self.cooldown_enemy<=100):
            if(self.position_enemy[1]>=0):
                self.position_enemy[1]+=self.numlst[self.a1]
                if(self.position_enemy[1]==0):
                    self.a1=0
                if(self.position_enemy[1]==400):
                    self.a1=1
        else:
            if(self.position_enemy[1]>=0):
                if(self.position_enemy[1]<=500):
                    self.position_enemy[1]-=self.numlst[self.a1]
                else:
                    self.position_enemy[1]-=300
                if(self.position_enemy[1]==0):
                    self.a1=0
                if(self.position_enemy[1]==400):
                    self.a1=1
                
    def draw_healthbar(self):
        pygame.draw.rect(self.screen,(255,0,0),(10,10,200,20))
        pygame.draw.rect(self.screen,(255,0,0),(590,10,400,20))
        pygame.draw.rect(self.screen,(0,255,0),(10,10,self.hc,20))
        pygame.draw.rect(self.screen,(0,255,0),(590,10,self.he,20))

    def collide(self):
        if self.bullet_rect.colliderect(self.enemy_rect):
            self.he-=10
            if(self.chim or self.chim1):
                if(self.chim):
                    self.chtim+=1
                    self.chim-=1
                if(self.chim):
                    self.chtim+=1
                    self.chim1-=1
                
                

    def collidechar(self,o,w,l):
        if o.colliderect(w):
            self.hc-=10
            if self.tim2:
                l[1]+=1
                self.tim2-=1

    def collidechar2(self,o,w,l):
        if o.colliderect(w):
            self.hc-=10
            self.kdidhit_2=1
            if self.tim21:
                l[1]+=1
                self.tim21-=1

    def text(self,w):
        if w==1:
            txt=self.font.render("YOU WIN",True,(0,0,255))
            self.screen.blit(txt,(300,50))
            self.con=False
        else:
            txt=self.font.render("YOU LOSE",True,(0,0,255))
            self.screen.blit(txt,(300,50))
            self.con=False

    def runn(self):
        rtrn=[0,0,0,0,0]
        run=True
        while run:
            self.draw_enemy_rec()
            self.draw_char_rec()
            self.draw_fire_rec(self.position_fire1)
            if(self.position_fire2[1]<=600):
                self.draw_fire2_rec(self.position_fire2)
                self.collidechar2(self.fire2_rect,self.char_rect_up,rtrn)
            self.collidechar(self.fire_rect,self.char_rect,rtrn)
            if(self.n):
                self.draw_bullet_rec(self.position_bullet1)
                self.collide()
            if(self.a):
                self.draw_bullet_rec(self.position_bullet2)
                self.collide()
            self.draw_bg()
            self.movebg()
            self.draw_healthbar()
            self.firecoold_animation()
            self.draw_char()
            self.movement()
            if(self.hc<=0):
                self.text(0)
                if(self.tim):
                    rtrn[0]=time.time()
                    self.tim-=1
            if (self.n):
                a=self.draw_bullet1(self.lst_bullet,self.position_bullet1)
            if(self.n):
                if self.he<=0:
                    self.text(1)
                    if(self.tim):
                        rtrn[4]=1
                        rtrn[0]=time.time()
            if (self.a):
                a=self.draw_bullet2(self.lst_fire_char,self.position_bullet2)
            if(self.a):
                if self.he<=0:
                    self.text(1)
                    if(self.tim):
                        rtrn[4]=1
                        rtrn[0]=time.time()
            self.draw_enemy()
            self.movement_enemy()
            if(self.cooldown_enemy==0):
                self.tim2=1
                self.position_fire1[0]=self.position_enemy[0]
                self.position_fire1[1]=self.position_enemy[1]
                self.position_fire2_1[0]=self.position_fire1[0]
                self.position_fire2_1[1]=self.position_fire1[1]
                self.cooldown_enemy=300
            if(self.cooldown_enemy==150):
                self.tim21=1
                self.position_fire2[0]=self.position[0]
                self.position_fire2[1]=0
                self.posf1=self.position[1]
            if(self.position_fire2[1]<=600):
                if(self.kdidhit_2==1):
                    if(self.cooldown_enemy<=30):
                        self.kdidhit_2=0
                    else:
                        self.draw_fire2_2(self.position)
                        self.position_fire2[1]+=5
                else:
                    self.draw_fire2(self.position_fire2)
            self.draw_fire1(self.position_fire1)
            self.draw_fire2_1(self.position_fire2_1)
            for i in pygame.event.get():
                if i.type==pygame.QUIT:
                    run=False
                if self.con:
                    if i.type==pygame.KEYDOWN:
                        if i.key==pygame.K_UP:
                            self.pos[0]=True
                        if i.key==pygame.K_DOWN:
                            self.pos[1]=True
                        if i.key==pygame.K_RIGHT:
                            self.pos[3]=True
                        if i.key==pygame.K_LEFT:
                            self.pos[2]=True
                        if i.key==pygame.K_x:
                            if self.cooldown==0:
                                rtrn[2]+=1
                                self.chim=1
                                self.position_bullet1[0]=self.position[0]
                                self.position_bullet1[1]=self.position[1]
                                self.cooldown=200
                                self.n+=1
                        if i.key==pygame.K_z:
                            if self.cooldown2==0: 
                                rtrn[2]+=1 
                                self.chim2=1
                                self.position_bullet2[0]=self.position[0]
                                self.position_bullet2[1]=self.position[1]
                                self.cooldown2=200
                                self.a+=1
                    if i.type==pygame.KEYUP:
                        if i.key==pygame.K_UP:
                            self.pos[0]=False
                        if i.key==pygame.K_DOWN:
                            self.pos[1]=False
                        if i.key==pygame.K_RIGHT:
                            self.pos[3]=False
                        if i.key==pygame.K_LEFT:
                            self.pos[2]=False
                        if i.key==pygame.K_x:
                            pass
            if(self.cooldown!=0):
                self.cooldown-=1
            if(self.cooldown2!=0):
                self.cooldown2-=1
            if(self.con==False):
                self.cool=1000
            else:
                self.cooldown_enemy-=1
            pygame.display.update()
            self.clock.tick(100)
        pygame.quit()
        rtrn[3]=self.chtim
        return rtrn

det=game().runn()
if(det[0]==0):
    pass
else:
    det[0]=det[0]-current_time
    with open("score_record.csv", 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(det)
    a=1
    while a:
        a=int(input("enter 1 to see pie char for Total WIN-LOSS Ratio\nenter 2 to see your score comparisons\nenter 0 to exit:\n"))
        if(a==1):
            df = pd.read_csv("score_record.csv")
            total_wins = df['win(1)'].sum()
            total_rows = df.shape[0]
            per=(total_wins/total_rows)*100
            labels = ['WIN', 'LOSS']
            sizes = [per,100-per]
            plt.figure(figsize=(8, 6))
            plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90, colors=['gold', 'Red'])
            plt.title('WIN-LOSS Ratio')
            plt.axis('equal')
            plt.show()
        elif(a==2):
            df = pd.read_csv("score_record.csv")
            average_row = df.mean()
            winning_rows = df[df['win(1)'] == 1]
            winning_rows['Sum_minus_hits_given'] = winning_rows[['Time taken', 'Hits taken', 'No of Fires Used']].sum(axis=1) - winning_rows['Hits given']
            min_index = winning_rows['Sum_minus_hits_given'].idxmin()
            winning_row = df.iloc[min_index]
            last_row = df.iloc[-1]
            parameters = df.columns[:]
            winning_values = winning_row[:]
            average_values = average_row[:]
            last_values = last_row[:]
            plt.figure(figsize=(10, 6))
            plt.plot(parameters, winning_values, label='Best', marker='o')
            plt.plot(parameters, average_values, label='Average', marker='s')
            plt.plot(parameters, last_values, label='Yours', marker='d')
            plt.xlabel('Parameters')
            plt.ylabel('Values')
            plt.title('Comparison of Best, Average and Yours')
            plt.xticks(rotation=45)
            plt.legend()
            plt.grid(True)
            plt.tight_layout()
            plt.show()

        elif(a==0):
            break
        else:
            pass
